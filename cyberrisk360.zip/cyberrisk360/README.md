# CyberRisk 360 — GRC Risk Management Demo

A responsive, zero-dependency, single-page risk management portfolio prototype designed for GitHub Pages.

## Features
- Add, edit, delete and search risks
- Inherent and residual risk scoring (likelihood × impact, each 1–5)
- Risk heat map and severity distribution
- Remediation tracker with owners, dates and status
- Control theme reference library
- CSV export, JSON import/export, printable executive report
- Browser-local persistence (localStorage)
- Six fictional sample risks for demo use

## Deploy to GitHub Pages
1. Create a public repository named `cyberrisk360` on GitHub.
2. Upload `index.html` (and optionally `README.md`) to the repository root.
3. Go to **Settings → Pages → Build and deployment → Deploy from a branch**.
4. Choose **main** and **/(root)**, then save.
5. Open `https://YOUR-USERNAME.github.io/cyberrisk360/` after GitHub finishes deploying.

## Important limitations
Educational prototype only. No backend, user accounts, access control, collaboration, audit trail or server-side data protection. Data is stored only in the browser used, and may be erased by clearing browser storage. Do not use real confidential, personal, or regulated data. Control themes are educational summaries, not verified framework mappings. Risk scores are illustrative and require organizational calibration for production use.

## Suggested future versions
- Evidence inventory with secure storage and RBAC
- Framework-specific control catalog and control testing
- Risk approval workflow and audit trail
- Secure backend and authentication
- Unit tests and accessibility audit
